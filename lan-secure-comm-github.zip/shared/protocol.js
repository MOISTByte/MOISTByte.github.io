"use strict";

const PROTOCOL_VERSION = 1;
const AUTH_CONTEXT = "lan-secure-comm-auth-v1";
const SECURE_CONTEXT = "lan-secure-comm-secure-v1";
const SESSION_CONTEXT = "lan-secure-comm-session-v1";

const PEER_STATES = Object.freeze({
  OFFLINE: "Offline",
  WAITING: "Waiting",
  HALF_OPEN: "Half Open",
  AUTHENTICATING: "Authenticating",
  CONNECTED: "Connected",
  FAILED: "Failed"
});

module.exports = {
  PROTOCOL_VERSION,
  AUTH_CONTEXT,
  SECURE_CONTEXT,
  SESSION_CONTEXT,
  PEER_STATES
};
