# LAN Secure Comm

Peer-to-peer encrypted communication for directly reachable LAN, Tailscale, WireGuard, and ZeroTier peers. Each node runs an Express server, a peer WebSocket endpoint, a local browser control endpoint, and WebRTC signaling.

## Setup

```bash
npm install
npm start
```

Open `http://localhost:3000` on each machine. Alice enters Bob's LAN/VPN IP address, and Bob enters Alice's IP address. A peer is marked `Connected` only after both WebSocket directions authenticate successfully.

## Security Model

- Ed25519 keys identify peers. Usernames are display-only and are never trusted.
- X25519 derives a shared session key after authentication.
- WebSocket signaling after authentication is encrypted with AES-256-GCM.
- WebRTC DataChannel chat payloads are additionally encrypted in the browser with AES-GCM.
- Audio, video, and screen media use WebRTC media security rather than asymmetric encryption.
- Nonces and timestamp windows prevent replay of authentication messages.
- Private keys are stored locally in `data/identity.json` and are never sent to peers.
- The `/local` browser WebSocket is loopback-only because it delivers the current session key to the local UI for DataChannel encryption.

## Operation Notes

- The peer WebSocket endpoint is `ws://<ip>:3000/peer`.
- The browser UI uses `ws://localhost:3000/local`.
- No STUN or TURN server is configured. Peers must be directly reachable.
- Browsers may require camera, microphone, and screen-sharing permissions.

## Project Layout

```text
server/      Express and local browser WebSocket gateway
client/      Browser UI controller and browser AES-GCM helpers
crypto/      Identity, authentication, key derivation, secure envelopes
signaling/   Peer WebSocket authentication and encrypted signaling
webrtc/      Browser WebRTC session manager
data/        Local identity storage
public/      HTML and CSS served by Express
shared/      Protocol constants
tests/       Node crypto and replay tests
```

## Verification

```bash
npm test
```
