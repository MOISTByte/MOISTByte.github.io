"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { generateIdentity, hydrateIdentity } = require("../crypto/identity");
const {
  createChallenge,
  signChallenge,
  verifyChallengeSignature,
  NonceCache
} = require("../crypto/authentication");
const { decryptJson, encryptJson } = require("../crypto/secure-channel");

function freshIdentity(name) {
  return hydrateIdentity(generateIdentity(name), ":memory:");
}

test("Ed25519 challenge signatures verify and reject tampering", () => {
  const alice = freshIdentity("Alice");
  const bob = freshIdentity("Bob");
  const challenge = createChallenge();
  const signature = signChallenge(alice, challenge, bob.ed25519PublicKeyPem);

  assert.equal(verifyChallengeSignature({
    identity: bob,
    challenge,
    signature,
    signerIdentityPublicKeyPem: alice.ed25519PublicKeyPem,
    signerX25519PublicKeyPem: alice.x25519PublicKeyPem
  }), true);

  assert.equal(verifyChallengeSignature({
    identity: bob,
    challenge: createChallenge(),
    signature,
    signerIdentityPublicKeyPem: alice.ed25519PublicKeyPem,
    signerX25519PublicKeyPem: alice.x25519PublicKeyPem
  }), false);
});

test("X25519 session derivation produces the same AES key on both peers", () => {
  const alice = freshIdentity("Alice");
  const bob = freshIdentity("Bob");

  const aliceKey = alice.deriveSessionKey(bob.x25519PublicKeyPem, bob.fingerprint);
  const bobKey = bob.deriveSessionKey(alice.x25519PublicKeyPem, alice.fingerprint);

  assert.deepEqual(aliceKey, bobKey);
  assert.equal(aliceKey.length, 32);
});

test("AES-GCM secure channel round trips JSON and rejects the wrong key", () => {
  const alice = freshIdentity("Alice");
  const bob = freshIdentity("Bob");
  const mallory = freshIdentity("Mallory");
  const aliceKey = alice.deriveSessionKey(bob.x25519PublicKeyPem, bob.fingerprint);
  const bobKey = bob.deriveSessionKey(alice.x25519PublicKeyPem, alice.fingerprint);
  const wrongKey = mallory.deriveSessionKey(alice.x25519PublicKeyPem, alice.fingerprint);

  const envelope = encryptJson(aliceKey, { type: "chat", payload: "hello" });

  assert.deepEqual(decryptJson(bobKey, envelope), { type: "chat", payload: "hello" });
  assert.throws(() => decryptJson(wrongKey, envelope));
});

test("nonce cache rejects replayed challenges", () => {
  const cache = new NonceCache();
  const challenge = createChallenge();

  assert.equal(cache.remember(challenge), true);
  assert.equal(cache.remember(challenge), false);
});
