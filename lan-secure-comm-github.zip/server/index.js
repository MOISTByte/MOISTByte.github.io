"use strict";

const http = require("http");
const path = require("path");
const express = require("express");
const WebSocket = require("ws");
const { loadOrCreateIdentity } = require("../crypto/identity");
const { PeerManager } = require("../signaling/peer-manager");
const { LocalGateway } = require("./local-gateway");

const PORT = Number(process.env.PORT || 3000);

const identity = loadOrCreateIdentity();
const peerManager = new PeerManager(identity);
const app = express();
const server = http.createServer(app);
const peerWss = new WebSocket.Server({ noServer: true });
const localWss = new WebSocket.Server({ noServer: true });

function isLoopback(address) {
  return ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(address);
}

app.disable("x-powered-by");
app.use("/", express.static(path.join(__dirname, "..", "public")));
app.use("/client", express.static(path.join(__dirname, "..", "client")));
app.use("/webrtc", express.static(path.join(__dirname, "..", "webrtc")));

app.get("/api/identity", (_request, response) => {
  response.json(identity.publicProfile());
});

peerWss.on("connection", (socket, request) => {
  peerManager.acceptIncoming(socket, request);
});

new LocalGateway({ wss: localWss, identity, peerManager });

server.on("upgrade", (request, socket, head) => {
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (url.pathname === "/peer") {
    peerWss.handleUpgrade(request, socket, head, (ws) => peerWss.emit("connection", ws, request));
    return;
  }
  if (url.pathname === "/local") {
    if (!isLoopback(request.socket.remoteAddress)) {
      socket.destroy();
      return;
    }
    localWss.handleUpgrade(request, socket, head, (ws) => localWss.emit("connection", ws, request));
    return;
  }
  socket.destroy();
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`LAN Secure Comm is listening on http://0.0.0.0:${PORT}`);
  console.log(`Local fingerprint: ${identity.shortFingerprint}`);
});
