"use strict";

class LocalGateway {
  constructor({ wss, identity, peerManager }) {
    this.wss = wss;
    this.identity = identity;
    this.peerManager = peerManager;
    this.clients = new Set();

    wss.on("connection", (socket) => this.handleClient(socket));
    peerManager.on("peer-state", (peer) => this.broadcast({ type: "peer_state", peer }));
    peerManager.on("peer-message", ({ peer, payload }) => {
      this.broadcast({ type: "peer_payload", peer, payload });
    });
  }

  handleClient(socket) {
    this.clients.add(socket);
    socket.send(JSON.stringify({
      type: "identity",
      identity: this.identity.publicProfile(),
      peers: this.peerManager.snapshots()
    }));

    socket.on("message", (data) => this.handleClientMessage(socket, data));
    socket.on("close", () => this.clients.delete(socket));
  }

  handleClientMessage(socket, data) {
    try {
      const message = JSON.parse(data.toString());
      if (message.type === "connect_peer") {
        this.peerManager.connectToPeer(message.ip);
        return;
      }
      if (message.type === "signal") {
        this.peerManager.sendToPeer(message.peerFingerprint, {
          type: "signal",
          signal: message.signal
        });
        return;
      }
      if (message.type === "set_username") {
        // Usernames are display-only. Authentication always uses keys.
        this.identity.username = String(message.username || "Local User").slice(0, 80);
        socket.send(JSON.stringify({
          type: "identity",
          identity: this.identity.publicProfile(),
          peers: this.peerManager.snapshots()
        }));
        return;
      }
      socket.send(JSON.stringify({ type: "error", error: `Unknown command: ${message.type}` }));
    } catch (error) {
      socket.send(JSON.stringify({ type: "error", error: error.message }));
    }
  }

  broadcast(message) {
    const serialized = JSON.stringify(message);
    for (const client of this.clients) {
      if (client.readyState === 1) {
        client.send(serialized);
      }
    }
  }
}

module.exports = {
  LocalGateway
};
