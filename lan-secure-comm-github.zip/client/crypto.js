const TEXT_ENCODER = new TextEncoder();
const TEXT_DECODER = new TextDecoder();
const AAD = TEXT_ENCODER.encode("lan-secure-comm-browser-datachannel-v1");

export function base64urlToBytes(value) {
  const padded = `${value}${"=".repeat((4 - (value.length % 4)) % 4)}`;
  const binary = atob(padded.replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

export function bytesToBase64url(bytes) {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/u, "");
}

export async function importSessionKey(sessionKeyBase64url) {
  return crypto.subtle.importKey(
    "raw",
    base64urlToBytes(sessionKeyBase64url),
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptJson(key, payload) {
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const plaintext = TEXT_ENCODER.encode(JSON.stringify(payload));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce, additionalData: AAD, tagLength: 128 },
    key,
    plaintext
  );
  return {
    type: "secure",
    alg: "AES-GCM",
    nonce: bytesToBase64url(nonce),
    ciphertext: bytesToBase64url(new Uint8Array(ciphertext))
  };
}

export async function decryptJson(key, envelope) {
  if (!envelope || envelope.type !== "secure" || envelope.alg !== "AES-GCM") {
    throw new Error("Invalid encrypted DataChannel message");
  }
  const plaintext = await crypto.subtle.decrypt(
    {
      name: "AES-GCM",
      iv: base64urlToBytes(envelope.nonce),
      additionalData: AAD,
      tagLength: 128
    },
    key,
    base64urlToBytes(envelope.ciphertext)
  );
  return JSON.parse(TEXT_DECODER.decode(plaintext));
}
