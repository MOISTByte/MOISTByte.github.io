import { PeerSession } from "/webrtc/peer.js";

const $ = (selector) => document.querySelector(selector);

const state = {
  socket: null,
  identity: null,
  peers: new Map(),
  sessions: new Map(),
  activePeer: null
};

const elements = {
  username: $("#username"),
  saveUsername: $("#saveUsername"),
  peerIp: $("#peerIp"),
  connectPeer: $("#connectPeer"),
  localFingerprint: $("#localFingerprint"),
  localState: $("#localState"),
  peerList: $("#peerList"),
  peerFingerprint: $("#peerFingerprint"),
  peerState: $("#peerState"),
  peerSession: $("#peerSession"),
  chatLog: $("#chatLog"),
  chatInput: $("#chatInput"),
  sendChat: $("#sendChat"),
  openChat: $("#openChat"),
  audioCall: $("#audioCall"),
  videoCall: $("#videoCall"),
  acceptCall: $("#acceptCall"),
  rejectCall: $("#rejectCall"),
  hangup: $("#hangup"),
  muteAudio: $("#muteAudio"),
  muteVideo: $("#muteVideo"),
  shareScreen: $("#shareScreen"),
  stopShare: $("#stopShare"),
  localVideo: $("#localVideo"),
  remoteVideo: $("#remoteVideo"),
  incomingCall: $("#incomingCall"),
  incomingText: $("#incomingText"),
  toast: $("#toast")
};

function toast(message) {
  elements.toast.textContent = message;
  elements.toast.hidden = false;
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => {
    elements.toast.hidden = true;
  }, 3600);
}

function connectLocalSocket() {
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  state.socket = new WebSocket(`${protocol}//${location.host}/local`);
  elements.localState.textContent = "Waiting";

  state.socket.onopen = () => {
    elements.localState.textContent = "Waiting";
  };
  state.socket.onclose = () => {
    elements.localState.textContent = "Offline";
    toast("Local server connection closed");
  };
  state.socket.onerror = () => toast("Local WebSocket error");
  state.socket.onmessage = (event) => handleServerMessage(JSON.parse(event.data));
}

function handleServerMessage(message) {
  if (message.type === "identity") {
    state.identity = message.identity;
    elements.username.value = message.identity.username;
    elements.localFingerprint.textContent = message.identity.shortFingerprint;
    for (const peer of message.peers || []) {
      upsertPeer(peer);
    }
    return;
  }
  if (message.type === "peer_state") {
    upsertPeer(message.peer);
    return;
  }
  if (message.type === "peer_payload" && message.payload.type === "signal") {
    const session = ensureSession(message.peer);
    session.handleSignal(message.payload.signal).catch((error) => toast(error.message));
    return;
  }
  if (message.type === "error") {
    toast(message.error);
  }
}

function upsertPeer(peer) {
  if (!peer || !peer.fingerprint) {
    return;
  }
  state.peers.set(peer.fingerprint, peer);
  if (!state.activePeer || state.activePeer === peer.fingerprint) {
    state.activePeer = peer.fingerprint;
    renderActivePeer();
  }
  renderPeers();
  if (peer.state === "Connected") {
    ensureSession(peer).updatePeer(peer).catch((error) => toast(error.message));
  }
}

function renderPeers() {
  elements.peerList.replaceChildren();
  for (const peer of state.peers.values()) {
    const button = document.createElement("button");
    button.className = `peer-row ${state.activePeer === peer.fingerprint ? "active" : ""}`;
    button.type = "button";
    button.innerHTML = `
      <span>
        <strong>${escapeHtml(peer.username || "Unknown")}</strong>
        <small>${escapeHtml(peer.shortFingerprint || peer.fingerprint.slice(0, 12))}</small>
      </span>
      <em>${escapeHtml(peer.state)}</em>
    `;
    button.addEventListener("click", () => {
      state.activePeer = peer.fingerprint;
      renderActivePeer();
      renderPeers();
    });
    elements.peerList.append(button);
  }
}

function renderActivePeer() {
  const peer = state.peers.get(state.activePeer);
  const connected = peer && peer.state === "Connected";
  elements.peerFingerprint.textContent = peer ? peer.shortFingerprint : "None";
  elements.peerState.textContent = peer ? peer.state : "Offline";
  elements.peerSession.textContent = peer && peer.sessionKeyId ? peer.sessionKeyId : "No session";
  for (const control of [
    elements.openChat,
    elements.audioCall,
    elements.videoCall,
    elements.sendChat,
    elements.muteAudio,
    elements.muteVideo,
    elements.shareScreen,
    elements.stopShare,
    elements.hangup
  ]) {
    control.disabled = !connected;
  }
}

function ensureSession(peer) {
  let session = state.sessions.get(peer.fingerprint);
  if (session) {
    return session;
  }
  session = new PeerSession({
    peer,
    localIdentity: state.identity,
    sendSignal(peerFingerprint, signal) {
      state.socket.send(JSON.stringify({ type: "signal", peerFingerprint, signal }));
    }
  });
  wireSessionEvents(session);
  state.sessions.set(peer.fingerprint, session);
  return session;
}

function wireSessionEvents(session) {
  session.addEventListener("ready", () => toast("Secure session key is ready"));
  session.addEventListener("chat-state", ({ detail }) => toast(`Chat channel ${detail.state}`));
  session.addEventListener("rtc-state", ({ detail }) => {
    if (state.activePeer === session.peer.fingerprint) {
      elements.peerState.textContent = `${session.peer.state} / WebRTC ${detail.state}`;
    }
  });
  session.addEventListener("chat", ({ detail }) => appendChat(detail.message, "remote"));
  session.addEventListener("chat-ack", ({ detail }) => {
    const row = document.querySelector(`[data-message-id="${detail.ackId}"]`);
    if (row) {
      row.querySelector("small").textContent = "Delivered";
    }
  });
  session.addEventListener("local-stream", ({ detail }) => {
    elements.localVideo.srcObject = detail.stream;
  });
  session.addEventListener("remote-stream", ({ detail }) => {
    elements.remoteVideo.srcObject = detail.stream;
  });
  session.addEventListener("incoming-call", ({ detail }) => {
    state.activePeer = session.peer.fingerprint;
    renderActivePeer();
    renderPeers();
    elements.incomingText.textContent = detail.video ? "Incoming video call" : "Incoming voice call";
    elements.incomingCall.hidden = false;
    elements.acceptCall.dataset.peer = session.peer.fingerprint;
    elements.rejectCall.dataset.peer = session.peer.fingerprint;
    elements.acceptCall.dataset.audio = String(detail.audio);
    elements.acceptCall.dataset.video = String(detail.video);
  });
  session.addEventListener("call-state", ({ detail }) => toast(`Call ${detail.state}`));
  session.addEventListener("screen-state", ({ detail }) => toast(detail.sharing ? "Screen sharing started" : "Screen sharing stopped"));
  session.addEventListener("error", ({ detail }) => toast(detail.error.message));
}

function activeSession() {
  const peer = state.peers.get(state.activePeer);
  if (!peer) {
    throw new Error("Select a connected peer first");
  }
  return ensureSession(peer);
}

function sessionForFingerprint(fingerprint) {
  const peer = state.peers.get(fingerprint);
  if (!peer) {
    throw new Error("Peer is no longer available");
  }
  return ensureSession(peer);
}

function appendChat(message, side) {
  const row = document.createElement("article");
  row.className = `chat-message ${side}`;
  row.dataset.messageId = message.id;
  const time = new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  row.innerHTML = `
    <p>${escapeHtml(message.payload)}</p>
    <small>${side === "local" ? "Sending" : time}</small>
  `;
  elements.chatLog.append(row);
  elements.chatLog.scrollTop = elements.chatLog.scrollHeight;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/gu, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;"
  }[char]));
}

elements.saveUsername.addEventListener("click", () => {
  state.socket.send(JSON.stringify({ type: "set_username", username: elements.username.value }));
});

elements.connectPeer.addEventListener("click", () => {
  state.socket.send(JSON.stringify({ type: "connect_peer", ip: elements.peerIp.value.trim() }));
});

elements.openChat.addEventListener("click", async () => {
  activeSession().ensureChatChannel();
  toast("Opening encrypted chat channel");
});

elements.sendChat.addEventListener("click", async () => {
  const text = elements.chatInput.value.trim();
  if (!text) {
    return;
  }
  try {
    const message = await activeSession().sendChat(text);
    appendChat(message, "local");
    elements.chatInput.value = "";
  } catch (error) {
    toast(error.message);
  }
});

elements.chatInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    elements.sendChat.click();
  }
});

elements.audioCall.addEventListener("click", () => activeSession().inviteCall({ audio: true, video: false }).catch((error) => toast(error.message)));
elements.videoCall.addEventListener("click", () => activeSession().inviteCall({ audio: true, video: true }).catch((error) => toast(error.message)));
elements.acceptCall.addEventListener("click", () => {
  elements.incomingCall.hidden = true;
  sessionForFingerprint(elements.acceptCall.dataset.peer).acceptCall({
    audio: elements.acceptCall.dataset.audio === "true",
    video: elements.acceptCall.dataset.video === "true"
  }).catch((error) => toast(error.message));
});
elements.rejectCall.addEventListener("click", () => {
  elements.incomingCall.hidden = true;
  sessionForFingerprint(elements.rejectCall.dataset.peer).rejectCall();
});
elements.hangup.addEventListener("click", () => activeSession().hangup());
elements.muteAudio.addEventListener("click", () => {
  elements.muteAudio.classList.toggle("active");
  activeSession().setAudioEnabled(!elements.muteAudio.classList.contains("active"));
});
elements.muteVideo.addEventListener("click", () => {
  elements.muteVideo.classList.toggle("active");
  activeSession().setVideoEnabled(!elements.muteVideo.classList.contains("active"));
});
elements.shareScreen.addEventListener("click", () => activeSession().startScreenShare().catch((error) => toast(error.message)));
elements.stopShare.addEventListener("click", () => activeSession().stopScreenShare().catch((error) => toast(error.message)));

connectLocalSocket();
