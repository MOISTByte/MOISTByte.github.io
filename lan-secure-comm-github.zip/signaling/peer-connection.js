"use strict";

const { EventEmitter } = require("events");
const { base64url } = require("../crypto/encoding");
const {
  assertFreshTimestamp,
  createChallenge,
  signChallenge,
  verifyChallengeSignature
} = require("../crypto/authentication");
const { publicFingerprint, shortFingerprint } = require("../crypto/identity");
const { decryptJson, encryptJson } = require("../crypto/secure-channel");
const { PROTOCOL_VERSION } = require("../shared/protocol");

class PeerConnection extends EventEmitter {
  constructor({ socket, direction, ip, identity, nonceCache }) {
    super();
    this.socket = socket;
    this.direction = direction;
    this.ip = ip;
    this.identity = identity;
    this.nonceCache = nonceCache;
    this.localChallenge = createChallenge();
    this.remoteProfile = null;
    this.sessionKey = null;
    this.authenticated = false;
    this.closed = false;

    socket.on("message", (data) => this.handleMessage(data).catch((error) => this.fail(error)));
    socket.on("close", () => this.close());
    socket.on("error", (error) => this.fail(error));

    if (socket.readyState === 1) {
      this.sendHello();
    } else {
      socket.once("open", () => this.sendHello());
    }
  }

  sendHello() {
    this.sendRaw({
      type: "auth_hello",
      version: PROTOCOL_VERSION,
      username: this.identity.username,
      timestamp: new Date().toISOString(),
      challenge: this.localChallenge,
      identityPublicKeyPem: this.identity.ed25519PublicKeyPem,
      x25519PublicKeyPem: this.identity.x25519PublicKeyPem
    });
    this.emit("state", "Authenticating");
  }

  async handleMessage(data) {
    const message = JSON.parse(data.toString());
    if (message.type === "auth_hello") {
      this.handleHello(message);
      return;
    }
    if (message.type === "auth_signature") {
      this.handleSignature(message);
      return;
    }
    if (message.type === "secure") {
      if (!this.authenticated || !this.sessionKey) {
        throw new Error("Received encrypted payload before authentication");
      }
      const payload = decryptJson(this.sessionKey, message);
      this.emit("secure-message", payload, this);
      return;
    }
    throw new Error(`Unsupported peer message type: ${message.type}`);
  }

  handleHello(message) {
    if (message.version !== PROTOCOL_VERSION) {
      throw new Error("Unsupported protocol version");
    }
    assertFreshTimestamp(message.timestamp);
    if (!this.nonceCache.remember(message.challenge)) {
      throw new Error("Replay detected: repeated authentication challenge");
    }

    const fingerprint = publicFingerprint(message.identityPublicKeyPem);
    if (fingerprint === this.identity.fingerprint) {
      throw new Error("Refusing to authenticate this node as its own peer");
    }

    this.remoteProfile = {
      username: String(message.username || "Unknown"),
      fingerprint,
      shortFingerprint: shortFingerprint(fingerprint),
      ed25519PublicKeyPem: message.identityPublicKeyPem,
      x25519PublicKeyPem: message.x25519PublicKeyPem
    };
    this.sessionKey = this.identity.deriveSessionKey(message.x25519PublicKeyPem, fingerprint);

    this.sendRaw({
      type: "auth_signature",
      version: PROTOCOL_VERSION,
      timestamp: new Date().toISOString(),
      signature: signChallenge(this.identity, message.challenge, message.identityPublicKeyPem)
    });
    this.emit("remote-profile", this.remoteProfile, this);
  }

  handleSignature(message) {
    if (!this.remoteProfile) {
      throw new Error("Received authentication signature before peer identity");
    }
    if (message.version !== PROTOCOL_VERSION) {
      throw new Error("Unsupported protocol version");
    }
    assertFreshTimestamp(message.timestamp);

    const valid = verifyChallengeSignature({
      identity: this.identity,
      challenge: this.localChallenge,
      signature: message.signature,
      signerIdentityPublicKeyPem: this.remoteProfile.ed25519PublicKeyPem,
      signerX25519PublicKeyPem: this.remoteProfile.x25519PublicKeyPem
    });

    if (!valid) {
      throw new Error("Invalid peer authentication signature");
    }

    this.authenticated = true;
    this.emit("authenticated", this);
  }

  sendSecure(payload) {
    if (!this.authenticated || !this.sessionKey) {
      throw new Error("Cannot send encrypted payload before authentication");
    }
    this.sendRaw(encryptJson(this.sessionKey, payload));
  }

  sendRaw(message) {
    if (this.socket.readyState === 1) {
      this.socket.send(JSON.stringify(message));
    }
  }

  sessionKeyBase64url() {
    return base64url(this.sessionKey);
  }

  close() {
    if (this.closed) {
      return;
    }
    this.closed = true;
    this.emit("closed", this);
  }

  fail(error) {
    this.emit("failed", error, this);
    try {
      this.socket.close();
    } catch (_error) {
      // Closing a broken socket is best-effort.
    }
  }
}

module.exports = {
  PeerConnection
};
