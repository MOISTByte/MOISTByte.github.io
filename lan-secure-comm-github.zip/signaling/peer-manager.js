"use strict";

const { EventEmitter } = require("events");
const WebSocket = require("ws");
const { NonceCache } = require("../crypto/authentication");
const { PEER_STATES } = require("../shared/protocol");
const { PeerConnection } = require("./peer-connection");

function normalizeIp(ip) {
  if (!ip) {
    return "";
  }
  return String(ip).replace(/^::ffff:/u, "");
}

class PeerManager extends EventEmitter {
  constructor(identity) {
    super();
    this.identity = identity;
    this.nonceCache = new NonceCache();
    this.peers = new Map();
    this.connections = new Set();
    this.outboundByIp = new Map();
  }

  connectToPeer(ip) {
    const normalizedIp = normalizeIp(ip).trim();
    if (!normalizedIp) {
      throw new Error("Peer IP is required");
    }

    const existing = this.outboundByIp.get(normalizedIp);
    if (existing && !existing.closed) {
      return existing;
    }

    const socket = new WebSocket(`ws://${normalizedIp}:3000/peer`);
    const connection = this.trackConnection({ socket, direction: "outbound", ip: normalizedIp });
    this.outboundByIp.set(normalizedIp, connection);
    this.emit("peer-state", {
      ip: normalizedIp,
      state: PEER_STATES.WAITING,
      direction: "outbound"
    });
    return connection;
  }

  acceptIncoming(socket, request) {
    const ip = normalizeIp(request.socket.remoteAddress);
    return this.trackConnection({ socket, direction: "inbound", ip });
  }

  trackConnection({ socket, direction, ip }) {
    const connection = new PeerConnection({
      socket,
      direction,
      ip,
      identity: this.identity,
      nonceCache: this.nonceCache
    });

    this.connections.add(connection);
    connection.on("remote-profile", () => this.upsertConnection(connection));
    connection.on("authenticated", () => this.upsertConnection(connection));
    connection.on("secure-message", (payload) => this.handleSecurePayload(connection, payload));
    connection.on("failed", (error) => this.handleConnectionFailure(connection, error));
    connection.on("closed", () => this.handleConnectionClosed(connection));
    return connection;
  }

  upsertConnection(connection) {
    if (!connection.remoteProfile) {
      return;
    }

    const fingerprint = connection.remoteProfile.fingerprint;
    const peer = this.peers.get(fingerprint) || {
      fingerprint,
      shortFingerprint: connection.remoteProfile.shortFingerprint,
      username: connection.remoteProfile.username,
      ip: connection.ip,
      inbound: null,
      outbound: null,
      state: PEER_STATES.AUTHENTICATING,
      sessionKey: null
    };

    peer[connection.direction] = connection;
    peer.username = connection.remoteProfile.username;
    peer.ip = connection.ip || peer.ip;
    peer.shortFingerprint = connection.remoteProfile.shortFingerprint;

    const inboundOk = Boolean(peer.inbound && peer.inbound.authenticated && !peer.inbound.closed);
    const outboundOk = Boolean(peer.outbound && peer.outbound.authenticated && !peer.outbound.closed);

    if (inboundOk && outboundOk) {
      peer.state = PEER_STATES.CONNECTED;
      peer.sessionKey = peer.outbound.sessionKey || peer.inbound.sessionKey;
    } else if (inboundOk || outboundOk) {
      peer.state = PEER_STATES.HALF_OPEN;
      peer.sessionKey = (peer.outbound && peer.outbound.sessionKey) || (peer.inbound && peer.inbound.sessionKey);
    } else {
      peer.state = PEER_STATES.AUTHENTICATING;
    }

    this.peers.set(fingerprint, peer);
    this.emit("peer-state", this.safePeer(peer));
  }

  handleSecurePayload(connection, payload) {
    if (!connection.remoteProfile) {
      return;
    }
    this.emit("peer-message", {
      peer: this.safePeer(this.peers.get(connection.remoteProfile.fingerprint)),
      payload
    });
  }

  handleConnectionFailure(connection, error) {
    const peer = connection.remoteProfile && this.peers.get(connection.remoteProfile.fingerprint);
    this.emit("peer-state", {
      fingerprint: peer && peer.fingerprint,
      shortFingerprint: peer && peer.shortFingerprint,
      ip: connection.ip,
      state: PEER_STATES.FAILED,
      error: error.message
    });
  }

  handleConnectionClosed(connection) {
    this.connections.delete(connection);
    if (connection.direction === "outbound" && this.outboundByIp.get(connection.ip) === connection) {
      this.outboundByIp.delete(connection.ip);
    }
    if (!connection.remoteProfile) {
      return;
    }

    const peer = this.peers.get(connection.remoteProfile.fingerprint);
    if (!peer) {
      return;
    }
    if (peer.inbound === connection) {
      peer.inbound = null;
    }
    if (peer.outbound === connection) {
      peer.outbound = null;
    }

    const hasAny = Boolean(peer.inbound || peer.outbound);
    peer.state = hasAny ? PEER_STATES.HALF_OPEN : PEER_STATES.OFFLINE;
    this.emit("peer-state", this.safePeer(peer));
  }

  sendToPeer(fingerprint, payload) {
    const peer = this.peers.get(fingerprint);
    if (!peer || peer.state !== PEER_STATES.CONNECTED) {
      throw new Error("Peer must be mutually connected before signaling");
    }

    const connection = [peer.outbound, peer.inbound].find((candidate) => (
      candidate && candidate.authenticated && !candidate.closed
    ));

    if (!connection) {
      throw new Error("No authenticated socket is available for this peer");
    }

    connection.sendSecure(payload);
  }

  snapshots() {
    return Array.from(this.peers.values()).map((peer) => this.safePeer(peer));
  }

  safePeer(peer) {
    if (!peer) {
      return null;
    }
    const sessionConnection = [peer.outbound, peer.inbound].find((connection) => (
      connection && connection.sessionKey && connection.authenticated && !connection.closed
    ));
    const exposeSession = peer.state === PEER_STATES.CONNECTED && sessionConnection;
    return {
      username: peer.username,
      fingerprint: peer.fingerprint,
      shortFingerprint: peer.shortFingerprint,
      ip: peer.ip,
      state: peer.state,
      hasInbound: Boolean(peer.inbound && peer.inbound.authenticated && !peer.inbound.closed),
      hasOutbound: Boolean(peer.outbound && peer.outbound.authenticated && !peer.outbound.closed),
      sessionKey: exposeSession ? sessionConnection.sessionKeyBase64url() : null,
      sessionKeyId: exposeSession ? this.identity.sessionKeyId(sessionConnection.sessionKey) : null
    };
  }
}

module.exports = {
  PeerManager,
  normalizeIp
};
