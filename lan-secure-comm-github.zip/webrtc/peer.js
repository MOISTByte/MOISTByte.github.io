import { decryptJson, encryptJson, importSessionKey } from "/client/crypto.js";

function createId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function preferOpus(transceiver) {
  if (!transceiver || !RTCRtpSender.getCapabilities) {
    return;
  }
  const capabilities = RTCRtpSender.getCapabilities("audio");
  if (!capabilities || !capabilities.codecs) {
    return;
  }
  const opus = capabilities.codecs.filter((codec) => codec.mimeType.toLowerCase() === "audio/opus");
  const rest = capabilities.codecs.filter((codec) => codec.mimeType.toLowerCase() !== "audio/opus");
  if (opus.length && transceiver.setCodecPreferences) {
    transceiver.setCodecPreferences([...opus, ...rest]);
  }
}

export class PeerSession extends EventTarget {
  constructor({ peer, localIdentity, sendSignal }) {
    super();
    this.peer = peer;
    this.localIdentity = localIdentity;
    this.sendSignal = sendSignal;
    this.polite = localIdentity.fingerprint > peer.fingerprint;
    this.makingOffer = false;
    this.ignoreOffer = false;
    this.sessionKey = null;
    this.channel = null;
    this.localStream = new MediaStream();
    this.remoteStream = new MediaStream();
    this.screenTrack = null;
    this.cameraTrack = null;
    this.pendingInvite = null;
    this.pc = this.createPeerConnection();
  }

  async updatePeer(peer) {
    this.peer = peer;
    if (peer.sessionKey && !this.sessionKey) {
      this.sessionKey = await importSessionKey(peer.sessionKey);
      this.emit("ready", { peer });
    }
  }

  createPeerConnection() {
    const pc = new RTCPeerConnection({ iceServers: [] });

    pc.onicecandidate = ({ candidate }) => {
      if (candidate) {
        this.sendSignal(this.peer.fingerprint, { kind: "candidate", candidate });
      }
    };

    pc.onconnectionstatechange = () => {
      this.emit("rtc-state", { state: pc.connectionState });
    };

    pc.ontrack = ({ track }) => {
      this.remoteStream.addTrack(track);
      this.emit("remote-stream", { stream: this.remoteStream });
    };

    pc.ondatachannel = ({ channel }) => {
      this.attachDataChannel(channel);
    };

    pc.onnegotiationneeded = async () => {
      try {
        this.makingOffer = true;
        await pc.setLocalDescription();
        this.sendSignal(this.peer.fingerprint, { kind: "description", description: pc.localDescription });
      } catch (error) {
        this.emit("error", { error });
      } finally {
        this.makingOffer = false;
      }
    };

    return pc;
  }

  ensureChatChannel() {
    if (this.channel) {
      return this.channel;
    }
    const channel = this.pc.createDataChannel("chat", { ordered: true });
    this.attachDataChannel(channel);
    return channel;
  }

  attachDataChannel(channel) {
    this.channel = channel;
    channel.onopen = () => this.emit("chat-state", { state: "open" });
    channel.onclose = () => this.emit("chat-state", { state: "closed" });
    channel.onerror = (event) => this.emit("error", { error: event.error || new Error("DataChannel error") });
    channel.onmessage = async (event) => {
      try {
        const envelope = JSON.parse(event.data);
        const payload = await decryptJson(this.sessionKey, envelope);
        if (payload.type === "chat") {
          this.emit("chat", { message: payload });
          await this.sendSecure({ type: "chat_ack", ackId: payload.id, timestamp: new Date().toISOString() });
        } else if (payload.type === "chat_ack") {
          this.emit("chat-ack", { ackId: payload.ackId });
        }
      } catch (error) {
        this.emit("error", { error });
      }
    };
  }

  async sendChat(text) {
    if (!this.sessionKey) {
      throw new Error("Session key is not ready");
    }
    const channel = this.ensureChatChannel();
    if (channel.readyState !== "open") {
      throw new Error("Chat channel is not open yet");
    }
    const message = {
      type: "chat",
      id: createId(),
      timestamp: new Date().toISOString(),
      sender: this.localIdentity.fingerprint,
      payload: text
    };
    await this.sendSecure(message);
    return message;
  }

  async sendSecure(payload) {
    if (!this.channel || this.channel.readyState !== "open") {
      throw new Error("DataChannel is not open");
    }
    this.channel.send(JSON.stringify(await encryptJson(this.sessionKey, payload)));
  }

  async handleSignal(signal) {
    if (signal.kind === "description") {
      const description = signal.description;
      const readyForOffer = !this.makingOffer && (this.pc.signalingState === "stable" || this.ignoreOffer);
      const offerCollision = description.type === "offer" && !readyForOffer;
      this.ignoreOffer = !this.polite && offerCollision;
      if (this.ignoreOffer) {
        return;
      }
      await this.pc.setRemoteDescription(description);
      if (description.type === "offer") {
        await this.pc.setLocalDescription();
        this.sendSignal(this.peer.fingerprint, { kind: "description", description: this.pc.localDescription });
      }
      return;
    }

    if (signal.kind === "candidate") {
      try {
        await this.pc.addIceCandidate(signal.candidate);
      } catch (error) {
        if (!this.ignoreOffer) {
          throw error;
        }
      }
      return;
    }

    if (signal.kind === "call-invite") {
      this.emit("incoming-call", signal);
      return;
    }
    if (signal.kind === "call-reject") {
      this.emit("call-state", { state: "rejected" });
      return;
    }
    if (signal.kind === "call-accept") {
      this.emit("call-state", { state: "accepted" });
      if (this.pendingInvite) {
        const constraints = this.pendingInvite;
        this.pendingInvite = null;
        await this.prepareLocalMedia(constraints);
      }
      return;
    }
    if (signal.kind === "call-hangup") {
      this.stopLocalMedia();
      this.emit("call-state", { state: "ended" });
    }
  }

  async inviteCall({ audio, video }) {
    this.pendingInvite = { audio, video };
    this.sendSignal(this.peer.fingerprint, { kind: "call-invite", audio, video });
  }

  async acceptCall({ audio, video }) {
    await this.prepareLocalMedia({ audio, video });
    this.sendSignal(this.peer.fingerprint, { kind: "call-accept" });
  }

  rejectCall() {
    this.sendSignal(this.peer.fingerprint, { kind: "call-reject" });
  }

  async prepareLocalMedia({ audio, video }) {
    const stream = await navigator.mediaDevices.getUserMedia({ audio, video });
    for (const track of stream.getTracks()) {
      this.localStream.addTrack(track);
      if (track.kind === "video") {
        this.cameraTrack = track;
      }
      const sender = this.pc.addTrack(track, stream);
      const transceiver = this.pc.getTransceivers().find((item) => item.sender === sender);
      if (track.kind === "audio") {
        preferOpus(transceiver);
      }
    }
    this.emit("local-stream", { stream: this.localStream });
  }

  setAudioEnabled(enabled) {
    for (const track of this.localStream.getAudioTracks()) {
      track.enabled = enabled;
    }
  }

  setVideoEnabled(enabled) {
    for (const track of this.localStream.getVideoTracks()) {
      track.enabled = enabled;
    }
  }

  async startScreenShare() {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    const [screenTrack] = stream.getVideoTracks();
    this.screenTrack = screenTrack;
    const videoSender = this.pc.getSenders().find((sender) => sender.track && sender.track.kind === "video");
    if (videoSender) {
      await videoSender.replaceTrack(screenTrack);
    } else {
      this.pc.addTrack(screenTrack, stream);
    }
    screenTrack.onended = () => this.stopScreenShare();
    this.emit("screen-state", { sharing: true });
  }

  async stopScreenShare() {
    if (!this.screenTrack) {
      return;
    }
    this.screenTrack.stop();
    const videoSender = this.pc.getSenders().find((sender) => sender.track && sender.track.kind === "video");
    if (videoSender) {
      await videoSender.replaceTrack(this.cameraTrack || null);
    }
    this.screenTrack = null;
    this.emit("screen-state", { sharing: false });
  }

  hangup() {
    this.stopLocalMedia();
    this.sendSignal(this.peer.fingerprint, { kind: "call-hangup" });
  }

  stopLocalMedia() {
    for (const sender of this.pc.getSenders()) {
      if (sender.track && this.localStream.getTracks().includes(sender.track)) {
        this.pc.removeTrack(sender);
      }
    }
    for (const track of this.localStream.getTracks()) {
      track.stop();
      this.localStream.removeTrack(track);
    }
    this.cameraTrack = null;
    this.screenTrack = null;
    this.emit("local-stream", { stream: this.localStream });
  }

  emit(type, detail) {
    this.dispatchEvent(new CustomEvent(type, { detail }));
  }
}
