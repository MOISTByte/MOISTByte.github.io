"use strict";

const { createCipheriv, createDecipheriv, randomBytes } = require("crypto");
const { SECURE_CONTEXT } = require("../shared/protocol");
const { base64url, fromBase64url } = require("./encoding");

function encryptJson(sessionKey, payload) {
  const nonce = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", sessionKey, nonce);
  cipher.setAAD(Buffer.from(SECURE_CONTEXT));
  const plaintext = Buffer.from(JSON.stringify(payload), "utf8");
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();

  return {
    type: "secure",
    alg: "AES-256-GCM",
    nonce: base64url(nonce),
    ciphertext: base64url(Buffer.concat([encrypted, tag]))
  };
}

function decryptJson(sessionKey, envelope) {
  if (!envelope || envelope.type !== "secure" || envelope.alg !== "AES-256-GCM") {
    throw new Error("Invalid secure envelope");
  }

  const nonce = fromBase64url(envelope.nonce);
  const body = fromBase64url(envelope.ciphertext);
  if (nonce.length !== 12 || body.length < 17) {
    throw new Error("Invalid encrypted payload");
  }

  const ciphertext = body.subarray(0, -16);
  const tag = body.subarray(-16);
  const decipher = createDecipheriv("aes-256-gcm", sessionKey, nonce);
  decipher.setAAD(Buffer.from(SECURE_CONTEXT));
  decipher.setAuthTag(tag);
  const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return JSON.parse(plaintext.toString("utf8"));
}

module.exports = {
  decryptJson,
  encryptJson
};
