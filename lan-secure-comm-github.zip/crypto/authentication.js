"use strict";

const { randomBytes, timingSafeEqual } = require("crypto");
const { AUTH_CONTEXT, PROTOCOL_VERSION } = require("../shared/protocol");
const { base64url, canonicalJson, fromBase64url } = require("./encoding");

const MAX_CLOCK_SKEW_MS = 5 * 60 * 1000;

class NonceCache {
  constructor(ttlMs = MAX_CLOCK_SKEW_MS) {
    this.ttlMs = ttlMs;
    this.values = new Map();
  }

  remember(nonce, now = Date.now()) {
    this.prune(now);
    if (this.values.has(nonce)) {
      return false;
    }
    this.values.set(nonce, now + this.ttlMs);
    return true;
  }

  prune(now = Date.now()) {
    for (const [nonce, expiresAt] of this.values.entries()) {
      if (expiresAt <= now) {
        this.values.delete(nonce);
      }
    }
  }
}

function createChallenge() {
  return base64url(randomBytes(32));
}

function assertFreshTimestamp(timestamp) {
  const time = Date.parse(timestamp);
  if (!Number.isFinite(time)) {
    throw new Error("Invalid authentication timestamp");
  }
  if (Math.abs(Date.now() - time) > MAX_CLOCK_SKEW_MS) {
    throw new Error("Authentication timestamp is outside the allowed window");
  }
}

function buildSignaturePayload({
  challenge,
  signerIdentityPublicKeyPem,
  signerX25519PublicKeyPem,
  verifierIdentityPublicKeyPem
}) {
  return canonicalJson({
    context: AUTH_CONTEXT,
    version: PROTOCOL_VERSION,
    challenge,
    signerIdentityPublicKeyPem,
    signerX25519PublicKeyPem,
    verifierIdentityPublicKeyPem
  });
}

function signChallenge(identity, remoteChallenge, verifierIdentityPublicKeyPem) {
  const payload = buildSignaturePayload({
    challenge: remoteChallenge,
    signerIdentityPublicKeyPem: identity.ed25519PublicKeyPem,
    signerX25519PublicKeyPem: identity.x25519PublicKeyPem,
    verifierIdentityPublicKeyPem
  });

  return base64url(identity.sign(payload));
}

function verifyChallengeSignature({
  identity,
  challenge,
  signature,
  signerIdentityPublicKeyPem,
  signerX25519PublicKeyPem
}) {
  const payload = buildSignaturePayload({
    challenge,
    signerIdentityPublicKeyPem,
    signerX25519PublicKeyPem,
    verifierIdentityPublicKeyPem: identity.ed25519PublicKeyPem
  });

  const signatureBuffer = fromBase64url(signature);
  if (signatureBuffer.length === 0) {
    return false;
  }
  return identity.verify(payload, signatureBuffer, signerIdentityPublicKeyPem);
}

function constantTimeEqualText(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && timingSafeEqual(left, right);
}

module.exports = {
  MAX_CLOCK_SKEW_MS,
  NonceCache,
  assertFreshTimestamp,
  buildSignaturePayload,
  constantTimeEqualText,
  createChallenge,
  signChallenge,
  verifyChallengeSignature
};
