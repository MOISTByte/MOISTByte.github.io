"use strict";

const fs = require("fs");
const path = require("path");
const {
  createHash,
  createPrivateKey,
  createPublicKey,
  diffieHellman,
  generateKeyPairSync,
  hkdfSync,
  sign,
  verify
} = require("crypto");
const { SESSION_CONTEXT } = require("../shared/protocol");
const { base64url } = require("./encoding");

const IDENTITY_PATH = path.join(__dirname, "..", "data", "identity.json");

function exportPrivatePem(keyObject) {
  return keyObject.export({ type: "pkcs8", format: "pem" });
}

function exportPublicPem(keyObject) {
  return keyObject.export({ type: "spki", format: "pem" });
}

function publicFingerprint(publicKeyPem) {
  const publicKey = createPublicKey(publicKeyPem);
  const der = publicKey.export({ type: "spki", format: "der" });
  return createHash("sha256").update(der).digest("hex");
}

function shortFingerprint(fingerprint) {
  return fingerprint.match(/.{1,4}/gu).slice(0, 8).join(":");
}

function generateIdentity(username = "Local User") {
  const ed25519 = generateKeyPairSync("ed25519");
  const x25519 = generateKeyPairSync("x25519");

  return {
    version: 1,
    username,
    createdAt: new Date().toISOString(),
    ed25519: {
      publicKey: exportPublicPem(ed25519.publicKey),
      privateKey: exportPrivatePem(ed25519.privateKey)
    },
    x25519: {
      publicKey: exportPublicPem(x25519.publicKey),
      privateKey: exportPrivatePem(x25519.privateKey)
    }
  };
}

function loadOrCreateIdentity(filePath = IDENTITY_PATH) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });

  if (!fs.existsSync(filePath)) {
    const identity = generateIdentity(process.env.LANCOMM_USERNAME || "Local User");
    fs.writeFileSync(filePath, `${JSON.stringify(identity, null, 2)}\n`, { mode: 0o600 });
  }

  const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
  return hydrateIdentity(raw, filePath);
}

function hydrateIdentity(raw, filePath = IDENTITY_PATH) {
  const edPrivateKey = createPrivateKey(raw.ed25519.privateKey);
  const edPublicKey = createPublicKey(raw.ed25519.publicKey);
  const xPrivateKey = createPrivateKey(raw.x25519.privateKey);
  const xPublicKey = createPublicKey(raw.x25519.publicKey);
  const fingerprint = publicFingerprint(raw.ed25519.publicKey);

  return {
    filePath,
    username: raw.username || "Local User",
    createdAt: raw.createdAt,
    ed25519PublicKeyPem: raw.ed25519.publicKey,
    x25519PublicKeyPem: raw.x25519.publicKey,
    fingerprint,
    shortFingerprint: shortFingerprint(fingerprint),
    sign(payload) {
      return sign(null, Buffer.from(payload), edPrivateKey);
    },
    verify(payload, signature, publicKeyPem) {
      return verify(null, Buffer.from(payload), createPublicKey(publicKeyPem), signature);
    },
    deriveSessionKey(remoteX25519PublicKeyPem, remoteIdentityFingerprint) {
      const sharedSecret = diffieHellman({
        privateKey: xPrivateKey,
        publicKey: createPublicKey(remoteX25519PublicKeyPem)
      });
      const orderedFingerprints = [fingerprint, remoteIdentityFingerprint].sort().join(":");
      const salt = createHash("sha256").update(orderedFingerprints).digest();
      return Buffer.from(hkdfSync("sha256", sharedSecret, salt, SESSION_CONTEXT, 32));
    },
    publicProfile() {
      return {
        username: this.username,
        fingerprint,
        shortFingerprint: this.shortFingerprint,
        ed25519PublicKeyPem: raw.ed25519.publicKey,
        x25519PublicKeyPem: raw.x25519.publicKey
      };
    },
    sessionKeyId(key) {
      return base64url(createHash("sha256").update(key).digest().subarray(0, 16));
    }
  };
}

module.exports = {
  IDENTITY_PATH,
  generateIdentity,
  hydrateIdentity,
  loadOrCreateIdentity,
  publicFingerprint,
  shortFingerprint
};
